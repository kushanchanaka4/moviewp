<?php
/*
Plugin Name: Importerv8
Plugin URI: https://gtech.rf.gd
Description: Importer Premium WordPress plugin for automatic import of movies, anime & tv series informations from TMDB exclusively for the Moviewp Theme.
Version: 8.1
Author: Ridwan Kulu
Author URI: https://gtech.rf.gd
License: Regular
*/

define("Importer",plugin_basename(__FILE__));
define("PLUGIN_DIR",__DIR__);

require_once PLUGIN_DIR."/vendor/autoload.php";


if(is_admin()){
    $moviewp = new \App\Bootstrap();
}